<?php
/**
 * Created by PhpStorm.
 * User: Narayanz
 * Date: 7/17/2018
 * Time: 7:20 PM
 */


?>

<!DOCTYPE html>
<html>
<head>
    <title>Message page</title>
</head>
<body>



</body>
</html>
