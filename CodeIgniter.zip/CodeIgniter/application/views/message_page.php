<!DOCTYPE html>
<html>
<head>
	<title>Message page</title>
</head>
<body>

<?php  echo message; ?>

</body>
</html>