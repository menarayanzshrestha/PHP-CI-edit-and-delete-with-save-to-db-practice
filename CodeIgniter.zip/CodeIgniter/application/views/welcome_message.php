<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>

<div id="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2"><HR/>
            <h4><?php if(isset($this_user)){echo 'Edit User';}else{echo 'New User';} ?></h4>
            <?php if (isset($success_message)) { ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php } ?>
            <?php if (isset($error_message)) { ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php } ?>
            <?php if ($this->session->flashdata('message') != '') { ?>
                <div class="alert alert-success"><?php echo $this->session->flashdata('message'); ?></div>
            <?php } ?>
             
            <form method = "POST" action= "<?php echo base_url(); ?><?php if(isset($this_user)){echo 'user-edit/'.$this_user['id'];}?>">
                <div class="form-group col-md-6">
                    <label for="username">Username:</label>
                    <input href="" id="username" name="username" type="text" class="form-control" value=" <?php if(isset($this_user)){echo $this_user['username'];}else{echo set_value('username');} ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="password">Password:</label>
                    <input href="" id="password" name="password" type="password" class="form-control">
                </div>
                <div class="form-group col-md-6">
                    <label>Gender:</label>
                    <input type="radio" name="gender" value="female" <?php if(isset($this_user)){if($this_user['gender']=='female'){echo 'checked';}} ?>>Female
                    <input type="radio" name="gender" value="male" <?php if(isset($this_user)){if($this_user['gender']=='male'){echo 'checked';}} ?>>Male
                    <input type="radio" name="gender" value="other" <?php if(isset($this_user)){if($this_user['gender']=='other'){echo 'checked';}} ?>>Other
                </div>
                <div class="form-group col-md-12">
                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
            <table class="table table-striped table-hovered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                foreach($users as $newuser) {
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $newuser['username']; ?></td>
                        <td><?php echo $this->encrypt->decode($newuser['password']); ?></td>
                        <td><?php echo $newuser['gender']; ?></td>
                        <td>
                            <a href="<?php echo base_url().'user-edit/'.$newuser['id']; ?>" class="btn btn-sm btn-info">Edit</a>
                            <a href="<?php echo base_url().'user-delete/'.$newuser['id']; ?>" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>